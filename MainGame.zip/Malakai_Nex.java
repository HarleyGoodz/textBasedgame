/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package textBasedGame;

/**
 *
 * @author User
 */
import java.util.Scanner;
public class Malakai_Nex {
    
    void Malakai_backStory(){
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("-----------------------------------------------");
        System.out.println("Malakai possesses the ability to steal and redistribute the powers of others, particularly those of magical origin. \n"
                + "press 'Enter' to continue....");
        scanner.nextLine();
        
        
        System.out.println("-----------------------------------------------");
        System.out.println("Over centuries, he has amassed a vast arsenal of abilities, manipulating people and nations to fuel his ambition. \n"
                + "Those who serve him are often granted immense power in exchange for their loyalty\n"
                + "press 'Enter' to continue....");
        scanner.nextLine();
        
        System.out.println("-----------------------------------------------");
        System.out.println("though he can revoke that power at will. His greatest strength lies in his ability to corrupt others, \n"
                + "turning potential heroes into his loyal pawns."
                + "press 'Enter' to continue....");
        scanner.nextLine();
    }
    
    
    
}
